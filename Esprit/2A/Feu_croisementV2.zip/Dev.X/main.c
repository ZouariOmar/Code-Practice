/* 
 * File:   main.c
 * Author: zouari_omar
 *
 * Created on October 2, 2024, 10:14 AM
 */

#define _XTAL_FREQ 4000000

#include <stdio.h>
#include <stdlib.h>
#include <htc.h>

/**
 * @breif ###�Initialize the vars
 */
void __init__() {
    TRISA = 0;
    TRISB = 0;
    TRISA0 = 1;
    PORTA = 0;
    PORTB = 0;
}

/**
 * 
 * @param argc
 * @param argv
 * @return 
 */
int main(int argc, char** argv) {
    __init__();

    while (1) {
        if (RA0) {
            PORTB = 0b11101110;
            RA1 = 1;
            __delay_ms(1000);
            RA1 = 0;
            PORTB = 0b11011011;
            RA2 = 1;
            __delay_ms(500);
            RA2 = 0;
            PORTB = 0b01111110;
            RA3 = 1;
            __delay_ms(1000);
            RA3 = 0;
        } else {
            PORTB = 0b11101110;
            PORTA = 0;
            RA2 = 1;
            __delay_ms(5);
            RA2 = 0;
        }
    }
    return (EXIT_SUCCESS);
}

