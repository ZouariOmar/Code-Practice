/* 
 * File:   main.c
 * Author: zouari_omar
 *
 * Created on October 2, 2024, 10:14 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <htc.h>

/**
 * @breif ###�Initialize the vars
 */
void __init__() {
    TRISB = 0;
    PORTB = 0;
}

/**
 * 
 * @param argc
 * @param argv
 * @return 
 */
int main(int argc, char** argv) {
    __init__();
    PORTB = 0b01001111;  // Deplay the number 3
    return (EXIT_SUCCESS);
}

