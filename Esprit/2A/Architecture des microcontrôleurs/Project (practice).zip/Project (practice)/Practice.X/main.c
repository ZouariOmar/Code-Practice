/* 
 * File:   main.c
 * Author: zouari_omar
 *
 * Created on September 18, 2024, 9:18 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <htc.h>

/**
 * @brief # The main project function
 * @param argc
 * @param argv
 * @return int
 */
int main(int argc, char** argv) {
    TRISA0 = 1;
    TRISA2 = 1;
    TRISB = 0;  // Inint all the TRISB port on 0
    
    
    
    RA0 = 0; RA1 = 0;
    PORTB = 0;
    
    if (!RA0 && !RA1)
        PORTB = 0b00000011;
    else if (RA0 && !RA1)
        PORTB = 0b00001100;
    else if (!RA0 && RA1)
        PORTB = 0b00110000;
    else
        PORTB = 0b11000000;
    
    return (EXIT_SUCCESS);
}

