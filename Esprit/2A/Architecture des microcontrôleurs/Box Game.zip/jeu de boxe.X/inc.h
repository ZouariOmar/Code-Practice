/* 
 * File:   inc.h
 * Author: zouari_omar
 * Created on October 15, 2024, 7:11 PM
 */

#ifndef INC_H
#define	INC_H

#define PLAYER_1_LED RB6
#define PLAYER_2_LED RB7
#define PLAYER_1_BUTTON RB1
#define PLAYER_2_BUTTON RB2
#define BCD_A 0b00001010
#define BCD_E 0b00001110
#define MAIN_BUTTON RB0
#define HEALTH 5

#define SET_HIGH(x) (x = 1)
#define SET_LOW(x) (x = 0)
#define DISPLAY(x, y) (x = y)

//? Functions declaration prototype part
void __init__();
void delay_ms(unsigned int);
int isZero(int8_t, int8_t);
//// void checkZeroCarry(int8_t, int8_t);

#endif	/* INC_H */

