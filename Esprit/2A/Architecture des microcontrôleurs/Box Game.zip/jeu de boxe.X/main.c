/* 
 * File:   main.c
 * Author: zouari_omar
 * Created on October 15, 2024, 7:08 PM
 */

//? Include prototype declaration part
#include <stdio.h>
#include <stdlib.h>
#include <htc.h>
#include "inc.h"

/**
 * @brief ### The main app function
 * @param argc int
 * @param argv char **
 * @return 
 */
int main(int argc, char **argv) {
   __init__();
   int8_t p1 = HEALTH, p2 = HEALTH;
   
   while (1) {
       if (MAIN_BUTTON == 1) {
            PORTA = 0b00000000;  // Set all PORTA pins to low
            if (PLAYER_1_BUTTON) {
                SET_HIGH(PLAYER_2_LED);
                delay_ms(2000);
                SET_LOW(PLAYER_2_LED);
                if (p2 > 0) p2--;
            } else if (PLAYER_2_BUTTON) {
                SET_HIGH(PLAYER_1_LED);
                delay_ms(2000);
                SET_LOW(PLAYER_1_LED);
                if (p1 > 0) p1--;
            }

       } else {
           if (isZero(p1 , p2))
                PORTA = BCD_E;  // Set all PORTA pins to low
           else
                PORTA = BCD_A;  // Set all PORTA pins to low
       }
   }
    return (EXIT_SUCCESS);
}


/**
 * @breif ###�Initialize the registers/ports
 */
void __init__() {
    TRISB = 0b00000111;  // Set RB0 and RB1 as inputs (1) and RB6 and RB7 as outputs (0)
    PORTB = 0b00000000;  // Set all PORTB pins to low (RB6 and RB7)
    
    TRISA = 0b11000000;  // Set RA* as outputs (0)
    PORTA = BCD_A;       // Set all PORTA pins to low
}

/**
 * @breif ### Break the app for Xms
 * @param ms unsigned int
 */
void delay_ms(unsigned int ms) {
    for (unsigned i = 0; i < ms; i++)
        for (unsigned j = 0; j < 46; j++);
}

/**
 * @brief ### Check if the subtraction of a and b result a zero
 * @param a int8_t
 * @param b int8_t
 * @return int
 */
int isZero(int8_t a, int8_t b) {
    int8_t result = a - b;
    return (STATUSbits.Z);  // Check Zero flag (Z)
}